const SPECIALTIES = [
  {
    id: 'pasteles',
    name: 'Pasteles Personalizados',
    desc: 'Diseños a tu gusto para cumpleaños, bodas y toda ocasión especial.',
  },
  {
    id: 'galletas',
    name: 'Galletas Artesanales',
    desc: 'Decoradas a mano, perfectas para regalar o compartir.',
  },
  {
    id: 'mesas',
    name: 'Mesas Dulces',
    desc: 'Postres variados para eventos, montados con cariño y estilo.',
  },
  {
    id: 'temporada',
    name: 'Postres de Temporada',
    desc: 'Sabores frescos que cambian con lo mejor de cada estación.',
  },
];

function Menu() {
  return (
    <section id="especialidades" className="max-w-6xl mx-auto px-8 md:px-14 py-24">
      <div className="text-center max-w-xl mx-auto mb-14">
        <span className="text-sm tracking-widest uppercase text-sage-dark font-semibold">
          Nuestro menú
        </span>
        <h2 className="font-display text-3xl md:text-4xl text-[#3D2C33] mt-3">
          Nuestras Especialidades
        </h2>
        <p className="text-[#6B5560] mt-3">
          Cuatro maneras de endulzar tu mesa, todas horneadas frescas cada día.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {SPECIALTIES.map((item) => (
          <article
            key={item.id}
            className="bg-white rounded-xl2 shadow-card overflow-hidden flex flex-col hover:-translate-y-1 transition-transform"
          >
            <div className="h-44 bg-[#F1EBE0] flex items-center justify-center">
              {/* Reemplaza por <img src={...} className="w-full h-full object-cover" /> */}
              <span className="text-[#A99C8E] text-xs px-4 text-center">{item.name}</span>
            </div>
            <div className="p-5">
              <h3 className="font-display text-lg text-[#3D2C33]">{item.name}</h3>
              <p className="text-sm text-[#6B5560] mt-2 leading-relaxed">{item.desc}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export default Menu;

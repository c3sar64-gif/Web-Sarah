import { useState } from 'react';

function Footer() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: conectar a servicio de correo / backend
    console.log('Contacto:', form);
  };

  return (
    <footer id="contacto" className="bg-mauve text-cream px-8 md:px-14 pt-20 pb-10">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16">
        <div>
          <h2 className="font-display text-2xl md:text-3xl mb-3">Hablemos de tu pedido</h2>
          <p className="text-sm opacity-85 max-w-md leading-relaxed">
            Cuéntanos qué celebras y armamos juntas el pastel o mesa dulce perfecta.
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-3.5 mt-8">
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Tu nombre"
                className="flex-1 rounded-xl2 border border-cream/30 bg-cream/10 placeholder-cream/60 text-cream text-sm px-4 py-3 outline-none focus:border-cream/60"
              />
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="Tu correo"
                className="flex-1 rounded-xl2 border border-cream/30 bg-cream/10 placeholder-cream/60 text-cream text-sm px-4 py-3 outline-none focus:border-cream/60"
              />
            </div>
            <textarea
              name="message"
              value={form.message}
              onChange={handleChange}
              rows={4}
              placeholder="Cuéntanos sobre tu pedido..."
              className="rounded-xl2 border border-cream/30 bg-cream/10 placeholder-cream/60 text-cream text-sm px-4 py-3 outline-none focus:border-cream/60 resize-none"
            />
            <button
              type="submit"
              className="w-fit rounded-full bg-rose-metallic hover:bg-rose-metallic-dark text-white text-sm font-medium px-6 py-3 transition-colors"
            >
              Enviar mensaje
            </button>
          </form>
        </div>

        <div className="flex flex-col justify-between">
          <div>
            <span className="font-display text-xl">Sarah</span>
            <p className="text-sm opacity-75 mt-2 max-w-xs leading-relaxed">
              Horneado con Amor — repostería artesanal para tus momentos más dulces.
            </p>
          </div>

          <div className="flex gap-4 my-6">
            <a
              href="https://wa.me/521234567890"
              target="_blank"
              rel="noreferrer"
              className="text-cream text-sm border border-cream/35 rounded-full px-5 py-2.5 hover:bg-cream/10 transition-colors"
            >
              WhatsApp
            </a>
            <a
              href="https://instagram.com/sarah.horneado"
              target="_blank"
              rel="noreferrer"
              className="text-cream text-sm border border-cream/35 rounded-full px-5 py-2.5 hover:bg-cream/10 transition-colors"
            >
              Instagram
            </a>
          </div>

          <p className="text-xs opacity-60 border-t border-cream/20 pt-5">
            © 2026 Sarah — Horneado con Amor. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;

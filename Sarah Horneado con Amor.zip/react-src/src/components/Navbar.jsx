import { useEffect, useState } from 'react';

const LINKS = [
  { label: 'Inicio', href: '#inicio' },
  { label: 'Especialidades', href: '#especialidades' },
  { label: 'Sobre Mí', href: '#sobre-mi' },
  { label: 'Contacto', href: '#contacto' },
];

function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-cream/95 shadow-md border-b border-taupe/30 backdrop-blur-sm' : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between px-8 md:px-14 py-4">
        <a href="#inicio" className="font-display text-2xl font-semibold text-mauve-dark">
          Sarah
        </a>

        <nav className="hidden md:flex items-center gap-10">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm font-medium text-[#3D2C33] hover:text-mauve transition-colors"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <a
          href="#contacto"
          className="hidden sm:inline-block rounded-full bg-rose-metallic hover:bg-rose-metallic-dark text-white text-sm font-medium px-5 py-2.5 transition-colors"
        >
          Pedir ahora
        </a>
      </div>
    </header>
  );
}

export default Navbar;

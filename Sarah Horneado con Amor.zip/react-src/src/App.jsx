import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Menu from './components/Menu';
import AboutSarah from './components/AboutSarah';
import Footer from './components/Footer';

function App() {
  return (
    <div className="font-body bg-cream text-[#3D2C33] min-h-screen overflow-x-hidden">
      <Navbar />
      <Hero />
      <Menu />
      <AboutSarah />
      <Footer />
    </div>
  );
}

export default App;

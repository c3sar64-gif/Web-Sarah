# Sarah — Horneado con Amor

Design system for **Sarah**, a Spanish-speaking artisanal home bakery ("Horneado con Amor" = "Baked with Love"). No codebase or Figma file was provided — this system is built entirely from two brand assets supplied by the user:

- `uploads/Logo.jpeg` — the primary logo lockup
- `uploads/Paleta de colores.png` — a one-page brand sheet: color palette (with hex/CMYK/RGB), type sample, and 5 logo lockup variations (horizontal, icon-only, dark-background, monochrome, round badge)

There is no attached codebase, Figma link, or slide deck for this brand. Everything here is inferred from those two images plus reasonable bakery-brand defaults, and should be treated as a v1 starting point, not ground truth from production material.

## Products / surfaces
Only one implied surface: a small bakery's ordering website (home/menu/cart). No mobile app, dashboard, or other product was indicated.

## Index
- `styles.css` — root stylesheet, imports everything below
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `base.css`
- `assets/` — `logo.jpeg` (only version available — raster, cream background, no vector/transparent source), `brand-guide-reference.png` (full source sheet, kept for reference)
- `guidelines/` — specimen cards: `colors-*`, `type-*`, `spacing-*`, `brand-*`
- `components/` — reusable UI primitives (see below)
- `ui_kits/bakery-site/` — homepage/order-flow recreation (`index.html`, `HomePage.jsx`)
- `SKILL.md` — portable skill definition for Claude Code

## Components
No component library source was provided, so a standard baseline set was authored, sized to a small e-commerce/ordering site:
- `components/core/` — Button, Badge, Tag, Card
- `components/forms/` — Input, Select, Checkbox, Radio, Switch
- `components/feedback/` — Toast, Tooltip
- `components/navigation/` — Tabs
- `components/overlay/` — Dialog

Full list: Button, Badge, Tag, Card, Input, Select, Checkbox, Radio, Switch, Toast, Tooltip, Tabs, Dialog.

### Intentional additions
Every component above is an intentional addition (no source defined an inventory) — sized to what a small ordering site needs. Nothing beyond this list should be assumed to exist; add further primitives (e.g. Accordion, Avatar) only as a real screen needs them.

## Content fundamentals
- **Language**: Spanish (Latin American / neutral, informal "tú" register — matches the slogan "Horneado con Amor").
- **Tone**: warm, intimate, artisanal — "made with love," never corporate or salesy. Short, sincere lines over feature lists.
- **Casing**: sentence case for body copy and buttons ("Pedir ahora", "Ver menú"); the wordmark itself uses title case.
- **Voice**: first-person-plural warmth ("horneamos", "nuestro menú") rather than distant "we/company" language; keep sentences short and sensory (texture, freshness, hand-made).
- **Emoji**: none in brand material — avoid in UI copy; a cart glyph (🛒) is used sparingly in the UI kit purely as a functional icon, not brand voice.
- Example lines used in this kit: "Dulces momentos, hechos a mano", "Pasteles, galletas y postres artesanales, horneados frescos cada día para tu mesa."

## Visual foundations
- **Color**: soft, muted, "greige"-adjacent palette — Rosa Metálico `#E0A9A1` (primary, warm metallic pink), Verde Salvia Suave `#A3B59D` (organic accent), Crema de Papel `#F8F4ED` (page background, paper-like), Malva Profundo `#734F62` (rich contrast — headlines on dark, links, footers), Gris Topo Cálido `#D1C5B8` (neutral). Backgrounds are flat, warm, paper-toned — no gradients anywhere in the source material.
- **Type**: a high-contrast serif for the wordmark and headings, paired with a light, geometric sans for the slogan/body. Elegant and airy — generous letter-spacing on the secondary line ("Horneado con Amor" is set in a light weight with open tracking).
- **Spacing**: no explicit spacing values were given; a conventional 4px-based scale was authored (4–128px) sized for a breathable, uncluttered layout consistent with the airy logo lockup.
- **Backgrounds**: flat cream/paper tone (`--surface-page`) as the dominant field; the deep malva shows up as a rare full-bleed dark section (e.g. the "dark background" logo lockup shows this pattern is brand-approved). No photographic textures, no repeating patterns, no gradients in any source material.
- **Animation**: none specified. UI kit uses only short, standard ease-out fades/translate on hover (150–250ms) — nothing bouncy, nothing flashy, matching the calm brand tone.
- **Hover states**: buttons darken slightly and lift 1px; ghost/secondary buttons get a soft sunken-cream fill. No color inversion, no heavy shadows appearing on hover.
- **Press/active**: not shown in source; kept subtle (no visible press states beyond hover carried through) — extend conservatively if needed.
- **Borders**: thin (1px), warm taupe (`--border-default` / `--taupe-warm`), never black. Used sparingly — most separation comes from whitespace and soft shadows, not rules.
- **Shadows**: soft, warm-tinted (mauve-tinted rgba, not pure black) — `--shadow-soft` for resting cards, `--shadow-card` for standard cards, `--shadow-lifted` for modals/toasts. No hard/high-contrast shadows.
- **Corner radii**: soft and rounded throughout — `--radius-md` (14px) for inputs/small cards, `--radius-lg` (22px) for cards/images/modals, full pill radius for buttons and tags — echoing the rounded "etiqueta redonda" badge lockup in the brand sheet.
- **Cards**: white fill, no border, soft rose/mauve-tinted shadow, large rounded corners — clean and minimal, image-forward (image on top, text below).
- **Transparency/blur**: not used in any source material; avoid frosted-glass/blur effects — keep surfaces opaque.
- **Imagery color vibe**: no photography was supplied. Given the palette, imagery should lean warm, soft, natural light, close-up/food-styling shots (not cool-toned, not black & white, no heavy grain) — implied by the palette, not confirmed by a source photo.
- **Layout**: centered, generous margins, sticky simple header; nothing fixed/pinned beyond the header in the UI kit.

## Iconography
No icon system, icon font, or SVG set was found in the provided material. The only graphic motif present is the single hand-drawn line-art illustration above the wordmark (a rose, a rolling pin, and a whisk) — reused as-is (`guidelines/brand-motif.card.html`); never redraw it. For functional UI glyphes (cart, close, checkmark) this kit uses plain Unicode characters (✓, ✕, 🛒) rather than an icon library, since no icon system was specified — treat these as placeholders and swap in a real icon set (e.g. Lucide) if the brand adopts one later.

## Fonts — substitution flagged
No font files were provided, only a specimen sheet showing letterform samples. The wordmark's serif does not exactly match any single stock Google Font, but is closest in spirit to a warm, moderate-contrast serif; **Playfair Display** was substituted for the display/heading role and **Poppins** (Light/Regular/Medium/Semibold) for the secondary/body role, loaded from Google Fonts in `tokens/typography.css`.

**Please share the real brand font files (or their names) if you have them** — the current choice is a best-effort visual match, not a confirmed brand font.

## Logo
Only a flattened raster JPEG (`assets/logo.jpeg`, cream background baked in) was provided — no vector (SVG/AI) or transparent-background version. It cannot be cleanly placed on a non-cream background as-is. The full reference sheet (`assets/brand-guide-reference.png`) shows 5 approved lockup variations (horizontal, icon-only, dark-background, monochrome, round badge) that exist in the brand but were not supplied as separate files — only the horizontal version's photo is available to use directly.
